# calculadora-purple
![Captura da Web_4-8-2022_124341_127 0 0 1](https://user-images.githubusercontent.com/106199899/182889561-ecf83a4a-b01b-4425-bc0a-8001cbe4576e.jpeg)
